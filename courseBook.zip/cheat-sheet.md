PS: DO ALL PASSWORDS FOR TESTING TO BE : 123456

DON'T FORGET TO ADD METHODS TO HBS FORMS

# Express App Cheat Sheet

1. Initialize project ---> npm init --yes
2. Nodemon
    * Install as dev dependency & config nodemon ---> npm i -D nodemon
    * Add start script
3. Express
    * Install express
    * Start initial express server
    * Add static route
    * Add static middleware ---> basically create the public folder
    * Add resources (css and images) to public folder (the static middleware)
    * Add body parser ---> app.use(express.urlencoded({ extended: false }));
    * Add routes module ---> create routes.js
4. Handlebars
    * Install express-handlebars
    * Config handlebars with express
    * Add views folder with resources
    * Add home view
    * Add home controller
    * Add main layout
    * Add partials dir
    * Add home controller
    * Add home controller to routes
5. Database
    * Install  mongoose
    * Setup db connection
    * Add user model
6. Register
    * Fix navigation links
    * Add register page (view (register.hbs), controller, route)
    * Add register page (view, controller, route)
    * Fix register form
    * Add post register action ---> router.post('/register')
    * Add authService
    * Install bcrypt
    * Hash password
    * Check confirm password ---> in authService.js ; but can also be done in User.js with virtual property
    * Check if user exists
7. Login
    * Install jsonwebtoken
    * Install cookie-parser
    * Add cookieParser middleware
    * Optionally: convert to promise based
    * Add login page ---> change login.html to hbs and add endpoint to authController.js
    * Fix login form
    * Add login post action ---> in authController
    * Add authService login method
        * validate user
        * validate password
        * generate token
    * Return cookie
    * Modify register for auto login
8. Logout
9. Authentication & Authorization
    * Add auth middleware
    * Check token if guest
    * Verify token
    * Attach user to request object and res.locals
    * Use middleware in express
    * Add isAuth route guard
10. Error handling
    * Add notifications
    * Add getErrorMessage util
    * Add register error handling
    * Add login error handling
11. Last fixes
    * Dynamic navigation




------------------------------------------
2nd stage cheat-sheet (don't necessarily follow this; it was not made by the teacher)

1.	Change DB name in constants.
2.	Replace the content in public folder.
3.	Replace and fix home, 404 and main.hbs.
4.	Fix navigation links.
5.	Replace login and register pages, fix names, method, errors, links.
6.	Create model for the required entity.
7.	Add service for the entity.
8.	Add controller for the endpoints connected to that entity.
9.	Create and save new entry in DB.
10.	Render dynamically catalog.
11.	Render details page.
12.	Render edit page and populate with data. (Fill value attributes to maintain data).
13.	Edit data and redirect.
14.	Delete entry.
15.	Add the third button functionality.
16.	Add extra functionality.
17.	Route guards.
18.	Mongoose schema validations.